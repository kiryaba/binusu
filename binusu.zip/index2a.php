<?php require_once('header.php');?>

    <header class="home">
	
	
		<div class="home_wrap" style="opacity:1;">
		
		
		
			<div class="container other_pg">
				<div class="row">
					<div class="col-lg-12">
				
						
					<!--<div class="col-md-6 tm_member animateright animated fadeInRight">
						
						<div class="tm_content" style="padding:0 10%; padding-top: 20%;">
							<h2     style="text-align: center;"> Buy Bitcoin</h2>
							<p class="white">
								Binusu is the fast and easy way to buy bitcoin in Uganda.
							</p>
						</div>
					</div>-->
					<div class="col-md-6 tm_member tm_member1 animateleft animated fadeInLeft">
						
						<div class="tm_content" style="padding:16px 0%;">
						    <!-- form start -->
							<form action="#" method="post">
							<p class="white">
								<div class="offset-md-2 " id="inputs">
								
					
							
                            <div class="row">
                                <div class="col-sm-12">
								
								
								<div class="input-group">
                                        <span class="input-group-addon group-label">Do you have a</span>
                                       
										
										
										<div class="form-group">
   
										<select class="form-control selectpicker" id="currency">
										  <option id="ugx">Bitcoin</option>
										  <option>Light coin</option>
										  <option>Feather Coin</option>
										  <option>crypto 4</option>
										  <option>crypto 5</option>
										  
										</select>
										
										
									  </div>
									  
									  <span class="input-group-addon group-label">Wallet?</span>
									  
                                    </div>
								
								
								
								
                                    <div class="input-group">
                                        <!--<span class="input-group-addon group-label"></span>-->
										
                                        <input aria-label="" autocomplete="off" class=" bitcoin" id="btc" name="wallet" placeholder="BTC" type="radio" value="Yes" onclick="show1();" onclick="show3();" checked />
										<label class="form-check-label radio_label" style="    margin-right: 40px;">Yes</label>
										
										
                                        <input aria-label="" autocomplete="off" class="bitcoin" id="btc" name="wallet" placeholder="BTC" type="radio" value="No" onclick="show2();" onclick="show3();"/>
                                      <label class="form-check-label radio_label"> No
										</label>
										
                                    </div>
									<p><a href='#'>What is a wallet?</a></p>
									
                                </div>
								
								
								
								
								<div class="col-sm-12 hide1" id="div1">
								<p>Enter your {selected_crypto} address</p>
								
                                    <div class="input-group">
                                        <!--<span class="input-group-addon group-label"></span>-->
										
                                        <input aria-label="" autocomplete="off" class="form-control bitcoin" id="btc" name="address" placeholder="Enter Crypto Address" type="text" value=""/>
										
										
                                    </div>
									
									<div class="input-group">
									
									<div style="float:left; width:45%">
                                        <a href="#"><img src="img/back.png"/> </a>
										</div>
									    <div style="float:right; width:45%;text-align: right;">
                                        <input class="btn btn-primary btn-lg" data-target="#subscribeModal" data-toggle="modal" id="submit" name="submit" type="submit" value="Continue">
										</div>
                                    </div>
									
									
                                </div>
								
								
								
								<div class="col-sm-12 hide1" id="div2">
								<p><a href="#">Get a {selected_crypto} wallet</a></p>
								<p>Enter your {selected_crypto} address</p>
								
                                    <div class="input-group">
                                        <!--<span class="input-group-addon group-label"></span>-->
										
                                        <input aria-label="" autocomplete="off" class="form-control bitcoin" id="btc" name="address" placeholder="Enter Crypto Address" type="text" value="">
										
										
                                    </div>
									
									<div class="input-group">
									
									<div style="float:left; width:45%">
                                        <a href="#"><img src="img/back.png"/> </a>
										</div>
									    <div style="float:right; width:45%;text-align: right;">
                                        <input class="btn btn-primary btn-lg" data-target="#subscribeModal" data-toggle="modal" id="submit" name="submit" type="submit" value="Continue">
										</div>
                                    </div>
                                </div>
								
								
                            </div><!--row-->
							
							
                            
                        </div>
							</p>
							</form> <!-- form ends -->
						</div>
					</div>
					
				</div>
					
					
				
					</div>
				</div>
			</div>
		
    </header>
	
	
	
	<script>
	
	function show1(){
  document.getElementById('div1').style.display ='block';
  document.getElementById('div2').style.display ='none';
}
function show2(){
  document.getElementById('div1').style.display = 'none';
  document.getElementById('div2').style.display = 'block';
}


</script>
	
<?php require_once('footer.php');?>
	
    