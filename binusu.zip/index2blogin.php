<?php require_once('header.php');?>

    <header class="home">
	
	
		<div class="home_wrap" style="opacity:1;">
		
		
		
			<div class="container other_pg">
				<div class="row">
					<div class="col-lg-12" >
				
						
					<!--<div class="col-md-6 tm_member animateright animated fadeInRight">
						
						<div class="tm_content" style="padding:0 10%; padding-top: 20%;">
							<h2     style="text-align: center;"> Buy Bitcoin</h2>
							<p class="white">
								Binusu is the fast and easy way to buy bitcoin in Uganda.
							</p>
						</div>
					</div>-->
					<div class="col-md-6 tm_member tm_member1 animateleft animated fadeInLeft">
						
						<div class="tm_content" style="padding:0 10%;">
						    <!-- form start -->
							<form action="#" method="post">
							<p class="white">
								<div class="offset-md-2 " id="inputs">
								
					
							
                            <div class="row">
                                
								
								
								<div class="col-sm-12">
								<h3 style="text-align:;">Login</h3>
								<p><a href='index2bsignup.php'>Have no account? Create one here</a></p>
                                    <div class="input-group">
                                        
										<!--<span class="input-group-addon"><i class="fa fa-envelope"></i></span>-->
                                        <input style="float:left; width:48%" aria-label="" autocomplete="off" class="form-control bitcoin" id="btc" name="email" placeholder="Email" type="email" value=""/>
										<input style="float:right;width:48%" aria-label="" autocomplete="off" class="form-control bitcoin" id="btc" name="password" placeholder="Password" type="password" value=""/>
										
                                    </div>
									
									<p><a href='#'>Forgot Your Password?</a></p>
                                </div>
								
								
                            </div><!--row-->
							
							
                            <div class="row">
							
                                <div class="col-sm-12">
                                    <div class="input-group">
									
									<div style="float:left; width:45%">
                                        <a href="#"><img src="img/back.png"/> </a>
										</div>
									    <div style="float:right; width:45%;text-align: right;">
                                        <input class="btn btn-primary btn-lg" data-target="#subscribeModal" data-toggle="modal" id="submit" name="submit" type="submit" value="Login">
										</div>
                                    </div>
									
								
                                </div>
								
								
                            </div>
                        </div>
							</p>
							</form> <!-- form start -->
						</div>
					</div>
					
				</div>
					
					
				
					</div>
				</div>
			</div>
		
    </header>
	
<?php require_once('footer.php');?>
	
    