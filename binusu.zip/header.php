<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BINUSU | Bitcoin Exchange</title>
    <script type="text/javascript">
        function preloader(){
            document.getElementById("loading").style.display = "none";
            document.getElementById("content").style.display = "block";
        }//preloader
        window.onload = preloader;
		
	
		
		
	</script>
	
	<script type="text/javascript">
       
		$(document).ready(function () {
   var $scrollingDiv = $("#navbar");

   $(window).scroll(function () {
       $scrollingDiv.stop()
           .animate({
           "marginTop": ($(window).scrollTop() + 0) + "px"
       }, "slow");
       $scrollingDiv.css("background-color", (($(window).scrollTop() / $(document).height()) > 0.15) ? "orange" : "");
     });
});
		
		
	</script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="css/animate.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
	

    <!-- Fonts -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--<link href='http://fonts.googleapis.com/css?family=Montserrat:700' rel='stylesheet' type='text/css'>-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Arimo" rel="stylesheet">

	
	<script src="http://www.marghoobsuleman.com/misc/jquery.js"></script>
<!-- <msdropdown> -->
<link rel="stylesheet" type="text/css" href="css/msdropdown/dd.css" />
<script src="js/msdropdown/jquery.dd.min.js"></script>
<!-- </msdropdown> -->
<link rel="stylesheet" type="text/css" href="css/msdropdown/flags.css" />


    <!-- IE8 support for HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top" class="list_blog" data-spy="scroll" data-target=".navbar-fixed-top">




<div id="loading"></div>
<div id="content">






    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" id="navbar" style="display: block;">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#page-top"><img src="img/logo.png"/><!--binusu--></a>
            </div>
			
			
			<!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" >
                <ul class="nav navbar-nav navbar-right" style=" margin-left: 24%;
    float: left !important;">
                    <li class="page-scroll" >
                        <a href="#">Home</a>
                    </li>
					<li class="page-scroll" title="Bitcoin Exchange Rate in UGX">
                        <a href="#about">About Us</a>
                    </li>
					<li class="page-scroll" title="Bitcoin Exchange Rate in USD">
                        <a href="#guide">How it works</a>
                    </li>
					</ul>
				
				<ul class="nav navbar-nav navbar-right">
				<li class="page-scroll">
                        <a class="btn btn-round btn-info" href="#">Login</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->

            
        </div>
        <!-- /.container-fluid -->
    </nav>