<footer class="text-center">
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col col-md-4" id="about">
                        <h4>About Binusu</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nibh elit, iaculis vel ligula in, egestas suscipit ex. Duis vehicula malesuada iaculis. Suspendisse sit amet mauris hendrerit, sagittis metus at, tincidunt tortor. In ut risus at nunc varius molestie. Praesent tempor hendrerit ligula in tincidunt. Praesent dui nisi, congue nec massa sit amet, porta lacinia lacus</p>
                    </div>
                    <div class="footer-col col-md-4">
                        <h4>What is a Wallet?</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nibh elit, iaculis vel ligula in, egestas suscipit ex. Duis vehicula malesuada iaculis. Suspendisse sit amet mauris hendrerit, sagittis metus at, tincidunt tortor. In ut risus at nunc varius molestie. Praesent tempor hendrerit ligula in tincidunt. Praesent dui nisi, congue nec massa sit amet, porta lacinia lacus</p>
                    </div>
                    <div class="footer-col col-md-4" id="guide">
                        <h4>How it works</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nibh elit, iaculis vel ligula in, egestas suscipit ex. Duis vehicula malesuada iaculis. Suspendisse sit amet mauris hendrerit, sagittis metus at, tincidunt tortor. In ut risus at nunc varius molestie. Praesent tempor hendrerit ligula in tincidunt. Praesent dui nisi, congue nec massa sit amet, porta lacinia lacus</p>
                    </div>
					
					
					
					
                </div>
				
				<ul class="list-inline">
			                <li><a href="#" class="">Privacu Policy</i></a>
                            <li><a href="#" class="">Terms & Conditions</i></a>
                            </li>
                            <li><a href="#" class="">Fees</i></a>
                            </li>
							<li><a href="#" class="">Copyright © 2017 - Binusu</i></a>
                            </li>
                            
                            
                        </ul>
            </div><!-- container -->
			
			
			
        </div>
        <!--<div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; 2017 - Binusu
                    </div>
                </div>
            </div>
        </div>-->
    </footer>

    <div class="scroll-top page-scroll visible-xs visble-sm">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>
</div>

    

    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/cbpAnimatedHeader.js"></script>
    <script src="js/jquery.appear.js"></script>
	<script src="js/businessplus.js"></script>
<script>
$(document).ready(function() {
	$("#countries").msDropdown();
})
</script>
</body>

</html>
