<?php require_once('header.php');?>

    <header class="home index1">
	
	
		<div class="home_wrap">
		
		
		
			<div class="container">
				<div class="row">
					<div class="col-lg-12" style="width: %;  margin: 0 auto;     float: none;">
				
						
					<div class="col-md-6 tm_member  tm_member1 welcome animateright animated fadeInRight">
						
						<div class="tm_content" style="padding:0 10%; padding-top: 0%;">
							<h2     style="text-align: center; color: #8cb301;"> Welcome to Binusu</h2>
							<p class="white">
								A secure, fast and convenient way to buy and sell Cryto Currency in East Africa.
							</p>
						</div>
					</div>
					<div class="col-md-6 tm_member tm_member1 animateleft animated fadeInLeft">
						
						<div class="tm_content" style="padding:0 10%;">
						    <!-- form start -->
							<form action="#" method="post">
							<p class="white">
								<div class="offset-md-2 " id="inputs">
								
								
								<div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group">
                                        <span class="input-group-addon group-label">You want</span>
                                       
										
										
										<div class="form-group">
   
										<select class="form-control selectpicker" id="currency">
										  <option id="ugx">Bitcoin</option>
										  <option>Light coin</option>
										  <option>Feather Coin</option>
										  <option>crypto 4</option>
										  <option>crypto 5</option>
										  
										</select>
										
										
									  </div>
									  
									  
									  
                                    </div>
                                </div>
                            </div>
							
							
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group">
                                        <span class="input-group-addon group-label">You Pay</span>
                                        <select class="form-control" id="exampleFormControlSelect1">
										  <option>Select Currency</option>
										  <option>UGX</option>
										  <option>TZ Shillings</option>
										  <option>Kenyan Shillings</option>
										  <option>Rwandan franc</option>
										  
										</select>
										

                                    </div>
                                </div>
                            </div>
							
							
							<div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group">
                                        <span class="input-group-addon group-label">Amount</span>
                                        <input aria-label="" autocomplete="off" class="form-control bitcoin" id="btc" name="btc_value" placeholder="Amount in selected currency" type="text" value="">
                                        
                                    </div>
                                </div>
                            </div>
                            
							
							
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group">
                                        <span class="input-group-addon group-label">You Get</span>
                                        <!--<input aria-label="" autocomplete="off" class="form-control bitcoin" id="btc" name="btc_value" placeholder="BTC" type="text" value="">-->
										
										<select class="form-control selectpicker" id="currency">
										  <option id="ugx">BTC</option>
										  <option>Light coin</option>
										  <option>Feather Coin</option>
										  <option>crypto 4</option>
										  <option>crypto 5</option>
										  
										</select>
                                        <!--<span class="input-group-addon"><i class="fa fa-btc"></i></span>-->
                                    </div>
                                </div>
                            </div>
							
							
							
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group" style="
    text-align: center;">
                                        <input class="btn btn-primary btn-lg" data-target="#subscribeModal" data-toggle="modal" id="submit" name="submit" type="submit" value="Continue">
                                    </div>
                                </div>
                            </div>
                        </div>
							</p>
							</form> <!-- form start -->
						</div>
					</div>
					
				</div>
					
					
				
					</div>
				</div>
			</div>
		
    </header>
	
<?php require_once('footer.php');?>
	
    