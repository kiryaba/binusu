<?php require_once('header.php');?>

    <header class="home">
	
	
		<div class="home_wrap" style="opacity:1;">
		
		
		
			<div class="container">
				<div class="row">
					<div class="col-lg-12" style="background:#e0e0e0;border-radius: 12px;">
				
						
					<!--<div class="col-md-6 tm_member animateright animated fadeInRight">
						
						<div class="tm_content" style="padding:0 10%; padding-top: 20%;">
							<h2     style="text-align: center;"> Buy Bitcoin</h2>
							<p class="white">
								Binusu is the fast and easy way to buy bitcoin in Uganda.
							</p>
						</div>
					</div>-->
					<div class="col-md-6 tm_member tm_member1 animateleft animated fadeInLeft">
						
						<div class="tm_content" style="padding:0 10%;">
						    <!-- form start -->
							<form action="#" method="post">
							<p class="white">
								<div class="offset-md-2 " id="inputs">
								
					
							
                            <div class="row">
                                
								
								
								<div class="col-sm-12">
								<h3 style="text-align:center;">Your Quote</h3>
								
									<img src="..." class="rounded mx-auto d-block" alt="..."/>
									
									<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Contact</a>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">...</div>
  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
</div>
								
                                </div>
								
								
								 
								
								
                            </div><!--row-->
							
							
							<div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group">
                                        <input class="btn btn-primary btn-lg" data-target="#subscribeModal" data-toggle="modal" id="submit" name="submit" type="submit" value="Sign Up" style="margin-right:20px;">
										
										<input class="btn btn-primary btn-lg" data-target="#subscribeModal" data-toggle="modal" id="submit" name="submit" type="submit" value="Cancel">
                                    </div>
									
                                </div>
								
								
                            </div>
							
							
                            
                        </div>
							</p>
							</form> <!-- form start -->
						</div>
					</div>
					
				</div>
					
					
				
					</div>
				</div>
			</div>
		
    </header>
	
<?php require_once('footer.php');?>
	
    