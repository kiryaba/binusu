<?php require_once('header.php');?>

    <header class="home">
	
	
		<div class="home_wrap" style="opacity:1;">
		
		
		
			<div class="container other_pg">
				<div class="row">
					<div class="col-lg-12">
				
						
					<!--<div class="col-md-6 tm_member animateright animated fadeInRight">
						
						<div class="tm_content" style="padding:0 10%; padding-top: 20%;">
							<h2     style="text-align: center;"> Buy Bitcoin</h2>
							<p class="white">
								Binusu is the fast and easy way to buy bitcoin in Uganda.
							</p>
						</div>
					</div>-->
					<div class="col-md-6 tm_member tm_member1 animateleft animated fadeInLeft">
						
						<div class="tm_content" style="padding:16px 0%;">
						    <!-- form start -->
							<form action="#" method="post">
							<p class="white">
								<div class="offset-md-2 " id="inputs">
								
					
							
                            <div class="row">
                                
								<div class="col-sm-12">
								<h3 style="text-align:;">Payment</h3>
								
                                    <div class="input-group">
                                        <!--<span class="input-group-addon group-label"></span>-->
										<span class="input-group-addon group-label">Select Payment Method</span>
                                        <div class="form-group">
										
										
										<select class="form-control" id="exampleFormControlSelect1" name="payment">
										  <option>Cash</option>
										  <option>Mobile Money</option>
										  <option>Card(Visa/Mastercard)</option>
										  
										</select>
									  </div>
										
										
                                    </div>
                                </div>
								
                            </div><!--row-->
							
							
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group">
									<input class="btn btn-primary btn-lg cancel_btn" data-target="#" data-toggle="modal" id="submit" name="submit" type="submit" value="Cancel" style="float:left;">
                                        <input class="btn btn-primary btn-lg" data-target="#" data-toggle="modal" id="submit" name="submit" type="submit" value="Make Payment" style="float:right">
										
										
                                    </div>
									
								
                                </div>
								
								
                            </div>
                        </div>
							</p>
							</form> <!-- form start -->
						</div>
					</div>
					
				</div>
					
					
				
					</div>
				</div>
			</div>
		
    </header>
	
<?php require_once('footer.php');?>
	
    